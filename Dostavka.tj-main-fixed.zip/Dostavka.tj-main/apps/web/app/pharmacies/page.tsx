import Link from "next/link";

export default function PharmaciesPage() {
  return (
    <div className="mx-auto min-h-screen max-w-[430px] bg-white p-4 shadow">
      <Link href="/" className="text-sm text-gray-600">
        ← Назад
      </Link>
      <div className="mt-6 rounded-3xl bg-gray-50 p-6 text-center">
        <div className="text-4xl">➕</div>
        <div className="mt-3 text-xl font-bold">Аптеки</div>
        <div className="mt-2 text-sm text-gray-600">
          Раздел скоро появится.
        </div>
      </div>
    </div>
  );
}
