import { redirect } from "next/navigation";

export default function SearchPage({
  searchParams,
}: {
  searchParams?: { q?: string };
}) {
  const q = searchParams?.q || "";
  redirect(`/restaurants?q=${encodeURIComponent(q)}`);
}
