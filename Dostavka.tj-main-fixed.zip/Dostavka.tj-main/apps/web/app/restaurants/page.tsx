import Link from "next/link";
import { apiGet } from "@/lib/api";

type Restaurant = {
  id: number;
  name: string;
  cuisine?: string | null;
  rating?: number | null;
  eta_min?: number | null;
  min_order_tjs?: number | null;
  is_active?: boolean;
};

export const dynamic = "force-dynamic";

export default async function RestaurantsPage({
  searchParams,
}: {
  searchParams?: { q?: string };
}) {
  const q = (searchParams?.q || "").trim().toLowerCase();
  const restaurants = (await apiGet<Restaurant[]>("/restaurants")) || [];

  const filtered = q
    ? restaurants.filter((r) => (r.name || "").toLowerCase().includes(q))
    : restaurants;

  return (
    <div className="mx-auto min-h-screen max-w-[430px] bg-white shadow">
      <div className="px-4 pt-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="text-sm text-gray-600">
            ← Назад
          </Link>
          <div className="text-lg font-bold">Рестораны</div>
          <div className="w-10" />
        </div>

        <form
          action="/restaurants"
          method="get"
          className="mt-3 flex items-center gap-2 rounded-full bg-gray-100 px-4 py-3"
        >
          <span className="text-sm text-gray-500">🔍</span>
          <input
            name="q"
            defaultValue={searchParams?.q || ""}
            placeholder="Поиск ресторана..."
            className="w-full bg-transparent text-sm outline-none placeholder:text-gray-400"
            autoComplete="off"
          />
        </form>
      </div>

      <div className="p-4">
        {filtered.length === 0 ? (
          <div className="rounded-2xl bg-gray-50 p-4 text-sm text-gray-600">
            Ничего не найдено.
          </div>
        ) : (
          <div className="grid gap-3">
            {filtered.map((r) => (
              <Link
                key={r.id}
                href={`/restaurants/${r.id}`}
                className="rounded-3xl border border-gray-100 bg-white p-4 shadow-sm active:scale-[0.99]"
              >
                <div className="text-base font-bold">{r.name}</div>
                <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-600">
                  {r.cuisine ? <span>{r.cuisine}</span> : null}
                  {typeof r.rating === "number" ? <span>⭐ {r.rating}</span> : null}
                  {typeof r.eta_min === "number" ? <span>⏱ {r.eta_min} мин</span> : null}
                  {typeof r.min_order_tjs === "number" ? (
                    <span>🚚 от {r.min_order_tjs} TJS</span>
                  ) : null}
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
