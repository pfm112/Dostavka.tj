import Link from "next/link";
import { apiGet } from "@/lib/api";

type Restaurant = {
  id: number;
  name: string;
  cuisine?: string | null;
  rating?: number | null;
  eta_min?: number | null;
  min_order_tjs?: number | null;
};

type Product = {
  id: number;
  restaurant_id: number;
  name: string;
  price_tjs: number;
};

export const dynamic = "force-dynamic";

export default async function RestaurantPage({
  params,
}: {
  params: { id: string };
}) {
  const id = Number(params.id);
  const restaurant = await apiGet<Restaurant>(`/restaurants/${id}`);
  const products = await apiGet<Product[]>(`/restaurants/${id}/products`);

  if (!restaurant) {
    return (
      <div className="mx-auto min-h-screen max-w-[430px] bg-white p-4 shadow">
        <Link href="/restaurants" className="text-sm text-gray-600">
          ← Назад
        </Link>
        <div className="mt-4 rounded-2xl bg-gray-50 p-4 text-sm text-gray-600">
          Ресторан не найден.
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto min-h-screen max-w-[430px] bg-white shadow">
      <div className="px-4 pt-4">
        <Link href="/restaurants" className="text-sm text-gray-600">
          ← Назад
        </Link>

        <div className="mt-2 text-2xl font-bold">{restaurant.name}</div>
        <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-600">
          {restaurant.cuisine ? <span>{restaurant.cuisine}</span> : null}
          {typeof restaurant.rating === "number" ? (
            <span>⭐ {restaurant.rating}</span>
          ) : null}
          {typeof restaurant.eta_min === "number" ? (
            <span>⏱ {restaurant.eta_min} мин</span>
          ) : null}
          {typeof restaurant.min_order_tjs === "number" ? (
            <span>🚚 от {restaurant.min_order_tjs} TJS</span>
          ) : null}
        </div>
      </div>

      <div className="p-4">
        <div className="text-sm font-semibold">Меню</div>

        {!products || products.length === 0 ? (
          <div className="mt-3 rounded-2xl bg-gray-50 p-4 text-sm text-gray-600">
            Пока нет товаров.
          </div>
        ) : (
          <div className="mt-3 grid gap-3">
            {products.map((p) => (
              <div
                key={p.id}
                className="rounded-3xl border border-gray-100 bg-white p-4 shadow-sm"
              >
                <div className="font-semibold">{p.name}</div>
                <div className="mt-1 text-sm text-gray-700">{p.price_tjs} TJS</div>
                <div className="mt-3">
                  <Link
                    href={`/cart?addProductId=${p.id}`}
                    className="inline-flex rounded-full bg-[var(--brand)] px-4 py-2 text-sm font-semibold text-white active:scale-[0.99]"
                  >
                    В корзину
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
