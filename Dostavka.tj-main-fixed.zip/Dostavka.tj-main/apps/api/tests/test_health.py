def test_import():
    import app.main  # noqa
